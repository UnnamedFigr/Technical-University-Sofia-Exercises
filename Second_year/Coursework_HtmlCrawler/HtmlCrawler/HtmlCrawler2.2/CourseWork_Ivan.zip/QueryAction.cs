﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HtmlCrawler2._2
{
    enum QueryAction
    {
        PRINT,
        SET,
        REMOVE
    }
}
