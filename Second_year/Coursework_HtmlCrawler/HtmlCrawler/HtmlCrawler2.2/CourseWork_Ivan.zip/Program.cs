﻿namespace HtmlCrawler2._2
{
    public class Program
    {
        static void Main(string[] args)
        {
            string htmlDoc = "C:\\Users\\kasap\\Desktop\\CourseWork2ndYear\\HtmlCrawler2.2\\testweb.html";
            ConsoleHandler handler = new ConsoleHandler(htmlDoc);
            handler.Run();
        }
    }
}